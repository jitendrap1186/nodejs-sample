# elasticbeanstalk-helloworld
Sample code to deploy a Node app into AWS ElasticBeanstalk

For more information read the Medium post -> https://medium.com/@xoor/deploying-a-node-js-app-to-aws-elastic-beanstalk-681fa88bac53
